let a = document.querySelector("h1").innerHTML="ka bat";
a.style.backgroundColor = "blue";
